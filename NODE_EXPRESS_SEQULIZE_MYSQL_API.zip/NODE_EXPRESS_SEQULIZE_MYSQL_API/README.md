API End Point:

Method: POST
End Point: http://localhost:8080/api/products/addProduct

Data -> Body-> raw/JSON

{
    "title": "iphone 12",
    "price": "3452.5",
    "description": "iphone is awesome",
    "published": "true"
}