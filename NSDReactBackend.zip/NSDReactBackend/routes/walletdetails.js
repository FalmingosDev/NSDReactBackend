var express = require('express');
var router = express.Router();
const walletdetailsController = require('../controllers/walletdetailsController');

const auth = require("../middleware/auth");

router.get('/', auth, walletdetailsController.wallet_data)

module.exports = router;