const db = require('../models');
const tokenDecode = require('../middleware/auth');
const {Sequelize, DataTypes, where} = require('sequelize');
const env = process.env.NODE_ENV || 'test';
const config = require(__dirname + '/../config/config.json')[env];
const { Op } = require("sequelize");


/*const reward = db.reward
const user_reward = db.user_reward
const wallet_detail = db.wallet_detail*/


let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

db.sequelize = Sequelize;


const wallet_data = async (req, res)=>{
    let userData = req.headers['x-access-token'];
    const tokenData = parseJwt(userData);
    try{
        let user_wallet = await sequelize.query('CALL wallet_details (:email)', 
                        {replacements: { email: tokenData.email }})

        response_data = {"message": "success", "user_wallet":user_wallet};
        res.status(200).send(response_data)
    }
    catch{
        response_data = {"message": "fail"}
        res.status(403).send(response_data)
    }
}


function parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse((atob(base64)))
};


module.exports = {
  wallet_data
}

/*sequelize
  .query('CALL login (:email, :pwd, :device)', 
        {replacements: { email: "me@jsbot.io", pwd: 'pwd', device: 'android', }})
  .then(v=>console.log(v));*/